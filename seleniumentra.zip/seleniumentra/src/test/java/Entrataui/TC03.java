package Entrataui;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC03 {

	@Test
	public void TC03_PageBottomTitles() {
		// TODO Auto-generated method stub

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.entrata.com/");
		driver.manage().window().maximize();

		// Get the tile of home page
		String actualPageTitle = driver.getTitle();

		// Validate title through Assertions
		Assert.assertEquals("Property Management Software | Entrata", actualPageTitle);
		System.out.println("Home Page title : " + actualPageTitle);

		// Accept the cookies
		driver.findElement(By.cssSelector("#rcc-confirm-button")).click();

		// Scroll the page to bottom
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		// Validate the titles present
		List<WebElement> titlesPresent = driver.findElements(By.xpath("//a[@class='title-footer-link']//self::a[1]"));
		System.out.println("Number of titles present : " + titlesPresent.size());
		for (WebElement row : titlesPresent) {
			System.out.println("Title: " + row.getText());
		}

		System.out.println("Third testcase is passed");
		driver.quit();

	}

}
