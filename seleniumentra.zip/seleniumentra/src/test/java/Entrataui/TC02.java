package Entrataui;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC02 {

	@Test
	public void TC02_SignInPage() {
		// TODO Auto-generated method stub

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.entrata.com/");
		driver.manage().window().maximize();

		// Get the tile of home page
		String actualPageTitle = driver.getTitle();

		// Validate title through Assertions
		Assert.assertEquals("Property Management Software | Entrata", actualPageTitle);
		System.out.println("Home Page title : " + actualPageTitle);
		// Clicked on Sign In button
		driver.findElement(By.linkText("Sign In")).click();

		// Accept the cookies
		driver.findElement(By.cssSelector("#rcc-confirm-button")).click();

		// Clicked on Resident login page
		driver.findElement(By.partialLinkText("Resident Login")).click();
		// Validate the welcome page for Resident portal
		driver.findElement(By.xpath("//*[@id=\"rpap-header\"]/div[2]/h1/span[1]")).getText();
		driver.findElement(By.xpath("//*[@id=\"rpap-header\"]/div[2]/h1/span[2]")).getText();

		System.out.println("Second testcase is passed");

		driver.quit();

	}

}
