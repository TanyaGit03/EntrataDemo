package Entrataui;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TC01 {

	@Test
	public  void TC01_WatchDemoPage() {
		// TODO Auto-generated method stub

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.entrata.com/");
		driver.manage().window().maximize();

		// Get the tile of home page
		String actualPageTitle = driver.getTitle();

		// Validate title through Assertions
		Assert.assertEquals("Property Management Software | Entrata", actualPageTitle);
		System.out.println("Home Page title : " + actualPageTitle);

		// Click on watchdemo button
		driver.findElement(By.xpath("//*[@id=\"gatsby-focus-wrapper\"]/div/div[1]/div/div/div[3]/a[1]")).click();

		// Enter firstName and LastName
		driver.findElement(By.id("FirstName")).sendKeys("Tanya");
		driver.findElement(By.id("LastName")).sendKeys("Singh");

		// Select value from unit count drop down
		WebElement fromUnit = driver.findElement(By.id("Unit_Count__c"));
		Select selectFrom = new Select(fromUnit);
		selectFrom.selectByValue("101 - 200");

		// Go back to Home page by clicking on Entrata logo
		driver.findElement(By.cssSelector("#asdfdfd9")).click();

		System.out.println("First testcase is passed");

		driver.quit();

	}

}
