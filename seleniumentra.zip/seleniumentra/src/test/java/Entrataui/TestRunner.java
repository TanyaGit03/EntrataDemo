package Entrataui;

import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

public class TestRunner {

	public void main(String[] args) {
		// TODO Auto-generated method stub

		JUnitCore junit = new JUnitCore();
        junit.addListener(new TextListener(System.out));

        // Run a single test class
       // junit.run(TC01.class);

         //Run multiple test classes
        Result result = junit.run(TC01.class, TC02.class, TC03.class);
        resultReport(result);
	}

	 public static void resultReport(Result result) {
	        // Print test results (you can customize this method)
	        System.out.println("Tests run: " + result.getRunCount());
	        System.out.println("Failures: " + result.getFailureCount());
	        // ... other details
	    }
}
